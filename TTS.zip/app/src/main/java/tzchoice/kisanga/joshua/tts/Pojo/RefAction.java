package tzchoice.kisanga.joshua.tts.Pojo;

/**
 * Created by user on 3/10/2017.
 */

public class RefAction {
    private int id;
    private String name;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
