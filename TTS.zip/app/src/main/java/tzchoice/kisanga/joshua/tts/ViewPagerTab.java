package tzchoice.kisanga.joshua.tts;

/**
 * Created by user on 3/25/2017.
 */

public class ViewPagerTab {
    public String title;
    public int notifications;

    public ViewPagerTab(String title, int notifications) {
        this.title = title;
        this.notifications = notifications;
    }
}
