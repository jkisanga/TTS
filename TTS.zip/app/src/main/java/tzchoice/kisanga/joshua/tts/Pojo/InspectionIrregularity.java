package tzchoice.kisanga.joshua.tts.Pojo;

/**
 * Created by user on 3/13/2017.
 */

public class InspectionIrregularity {
    private String irregularity;
    private String product;
    private String volume;
    private String value;
    private String action;
    private String actionAmount;
    private String receiptNo;

    public String getIrregularity() {
        return irregularity;
    }

    public void setIrregularity(String irregularity) {
        this.irregularity = irregularity;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getVolume() {
        return volume;
    }

    public void setVolume(String volume) {
        this.volume = volume;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getActionAmount() {
        return actionAmount;
    }

    public void setActionAmount(String actionAmount) {
        this.actionAmount = actionAmount;
    }

    public String getReceiptNo() {
        return receiptNo;
    }

    public void setReceiptNo(String receiptNo) {
        this.receiptNo = receiptNo;
    }
}
