package tzchoice.kisanga.joshua.tts;

/**
 * Created by user on 3/7/2017.
 */

public class Constant {

    //public final static String url = "http://192.168.43.90:8080/tts/public/";
   //public final static String url = "http://tts1.tfs.go.tz/";
   public final static String url = "http://tts.tfs.go.tz/";
    public final static String KEY_TPID = "tp_id";
    public final static String KEY_TPNO = "tp_no";
    public final static String KEY_CLIENT = "tp_client";
    public final static String KEY_CHECKPOINT_ID = "tp_checkpoint_id";
    public final static String KEY_CHECKPOINT = "tp_checkpoint";
    public final static String KEY_PRODUCT = "tp_product";
    public final static String KEY_USER_ID = "user_id";


    public final static String KEY_STATUS = "carg_status";
    public final static String KEY_IRREGULARITY = "irregularity";
    public final static String KEY_QUANTITY = "quantity";
    public final static String KEY_UNIT = "unit";
    public final static String KEY_VALUE = "value";
    public final static String KEY_ACTION = "action";
    public final static String KEY_ACTION_AMOUNT = "action_amount";
    public final static String KEY_RECEIPT_NO = "receipt_no";
    public final static String KEY_INSPECTOR = "inspected_by";
    public final static String KEY_DATE = "created_at";
}
